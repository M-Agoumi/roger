<?php
	echo "othman is hmar";
